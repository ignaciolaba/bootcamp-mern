import { PrimerComponente } from './components/PrimerComponente';

function App() {
  return (
    <PrimerComponente />
  )
}

export default App;
