import React from 'react'

export const PrimerComponente = () => {
  return (
    <div>
        <h1>Hello Dojo!</h1>
        <h3>Things I need to do:</h3>
        <ul>
            <li>Learn React</li>
            <li>CLim Mt. Everest</li>
            <li>Run a marathon</li>
            <li>Feed the dogs</li>
        </ul>
    </div>
  )
}
